﻿# EV Adoption & Market Trends Dashboard (Power BI)

## 📌 Project Overview
This project analyzes global electric vehicle (EV) adoption trends using data published by the International Energy Agency (IEA).  
The dashboard provides insights into EV stock, sales growth, regional dominance, and powertrain distribution.

## 📊 Dataset
- Source: International Energy Agency (IEA)
- Dataset: Global EV Data 2024
- Format: Excel (.xlsx)

## 🛠 Tools & Technologies
- Power BI
- DAX
- Data Modeling
- Data Visualization

## 🔍 Key Insights
- EV adoption has accelerated significantly after 2020
- China and Europe dominate global EV stock
- Battery Electric Vehicles (BEVs) lead the powertrain mix
- Passenger vehicles contribute the largest share of EV adoption

## 📈 Dashboard Features
- Interactive KPI cards (EV Stock, Sales, YoY Growth)
- Geographic analysis using maps
- Year-wise trend analysis
- Powertrain and category comparison
- Dynamic slicers for deeper exploration

## 📷 Dashboard Preview
![Dashboard Preview](images/dashboard_preview.png)

## 📂 Repository Structure
EV-Adoption-PowerBI-Dashboard/
│
├── data/
├── dashboard/
├── images/
└── README.md
